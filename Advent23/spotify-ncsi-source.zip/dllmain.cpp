#include <windows.h>
#include "patternscanner.h"

HANDLE thread = nullptr;
DWORD WINAPI InstallPatch(void* arguments) {
	std::uint8_t * ref = PatternScan((void*)GetModuleHandle(0), "E8 ? ? ? ? 5E FF 25 ? ? ? ? 6A 30");
	if(ref) {
		std::uint8_t * addr = ref + *(std::uint32_t *)(ref + 1) + 5;
		std::uint8_t patch[] = {0xC3, 0x90}; // ret, nop
		DWORD dwLastProtection;
		if (!VirtualProtect((void *)addr, sizeof(patch), PAGE_EXECUTE_READWRITE, &dwLastProtection))
			return 0;
		memcpy_s(addr, sizeof(patch), &patch, sizeof(patch));
		return VirtualProtect((void *)addr, sizeof(patch), dwLastProtection, &dwLastProtection);
	}
	return 0;
}

// Code sourced from: https://github.com/gamebooster/dll-plugins-loader

extern "C" UINT_PTR mProcs[12] = { 0 };
LPCSTR import_names[] = { "DirectSoundCaptureCreate", "DirectSoundCaptureCreate8", "DirectSoundCaptureEnumerateA",
                          "DirectSoundCaptureEnumerateW", "DirectSoundCreate", "DirectSoundCreate8", "DirectSoundEnumerateA",
                          "DirectSoundEnumerateW", "DirectSoundFullDuplexCreate", "DllCanUnloadNow", "DllGetClassObject", "GetDeviceID" };

int WINAPI DllMain(HINSTANCE instance, DWORD reason, PVOID reserved) {
	if (reason == DLL_PROCESS_ATTACH) {
		TCHAR expandedPath[MAX_PATH];
		ExpandEnvironmentStrings(L"%WINDIR%\\System32\\dsound.dll", expandedPath, MAX_PATH);
		auto module = LoadLibrary(expandedPath);
		if (!module) return 1;
		for (int i = 0; i < 12; i++)
			mProcs[i] = (UINT_PTR)GetProcAddress(module, import_names[i]);

		thread = CreateThread(nullptr, 0, InstallPatch, 0, 0, nullptr);
	}
	else if (reason == DLL_PROCESS_DETACH) {
		WaitForSingleObject(thread, INFINITE);
		CloseHandle(thread);
	}
	return 1;
}

extern "C" void __declspec(naked) DirectSoundCaptureCreate_wrapper() { __asm jmp mProcs[0*4]};
extern "C" void __declspec(naked) DirectSoundCaptureCreate8_wrapper() { __asm jmp mProcs[1*4]};
extern "C" void __declspec(naked) DirectSoundCaptureEnumerateA_wrapper() {__asm jmp mProcs[2*4]};
extern "C" void __declspec(naked) DirectSoundCaptureEnumerateW_wrapper() {__asm jmp mProcs[3*4]};
extern "C" void __declspec(naked) DirectSoundCreate_wrapper() { __asm jmp mProcs[4*4]};
extern "C" void __declspec(naked) DirectSoundCreate8_wrapper() { __asm jmp mProcs[5*4]};
extern "C" void __declspec(naked) DirectSoundEnumerateA_wrapper() { __asm jmp mProcs[6*4]};
extern "C" void __declspec(naked) DirectSoundEnumerateW_wrapper() { __asm jmp mProcs[7*4]};
extern "C" void __declspec(naked) DirectSoundFullDuplexCreate_wrapper() { __asm jmp mProcs[8*4]};
extern "C" void __declspec(naked) DllCanUnloadNow_wrapper() {__asm jmp mProcs[9*4]};
extern "C" void __declspec(naked) DllGetClassObject_wrapper() { __asm jmp mProcs[10*4]};
extern "C" void __declspec(naked) GetDeviceID_wrapper() { __asm jmp mProcs[11*4]};
